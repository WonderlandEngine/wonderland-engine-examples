import * as __wonderlandengine_components from '@wonderlandengine/components';
_registerEditor(__wonderlandengine_components);
