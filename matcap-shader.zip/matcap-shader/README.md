# Matcap Shader Example

This example demonstrates how to implement a custom matcap shader.

## Credit

-   [Emma Koch](https://twitter.com/emmakoch)

    -   Matcap `1.jpg`

-   From [devtalk.blender.org/](https://devtalk.blender.org/t/call-for-content-matcaps/737/366?page=5) **(CC0)**

    -   Matcap `2.jpg`
    -   Matcap `3.jpg`
    -   Matcap `5.jpg`
    -   Matcap `6.jpg`
    -   Matcap `8.jpg`

-   [Matcap Generator](https://www.kchapelier.com/matcap-studio/) **(MIT)**

    -   Matcap `4.jpg`
    -   Matcap `7.jpg`

-   [Blender](https://github.com/blender/blender) **(GNU General Public License, Version 3)**
    -   Matcap `9.jpg`
